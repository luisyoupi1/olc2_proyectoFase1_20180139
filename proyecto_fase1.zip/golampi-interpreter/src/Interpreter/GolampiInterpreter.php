<?php

require_once __DIR__ . '/../../generated/grammar/GolampiVisitor.php';
require_once __DIR__ . '/../../generated/grammar/GolampiBaseVisitor.php';
require_once __DIR__ . '/../Semantics/SymbolTable.php';
require_once __DIR__ . '/../Semantics/SemanticError.php';
require_once __DIR__ . '/BreakSignal.php';
require_once __DIR__ . '/ContinueSignal.php';
require_once __DIR__ . '/ReturnSignal.php';

class GolampiInterpreter extends GolampiBaseVisitor
{
    private string $output = '';
    private SymbolTable $symbolTable;
    private array $functions = [];
    private array $errors = [];
    private int $blockCounter = 0;
    private int $loopDepth = 0;
    private int $callDepth = 0;
    private ?string $currentFunction = null;

    public function __construct()
    {
        $this->symbolTable = new SymbolTable();
    }

    public function getOutput(): string
    {
        return $this->output;
    }

    public function getSymbolTable(): array
    {
        return $this->symbolTable->all();
    }

    public function getErrors(): array
    {
        return $this->errors;
    }

    private function addError(string $message, $context = null): void
    {
        $line = 0;
        $column = 0;

        if ($context !== null && method_exists($context, 'getStart')) {
            $start = $context->getStart();
            if ($start !== null) {
                $line = $start->getLine();
                $column = $start->getCharPositionInLine();
            }
        }

        $this->errors[] = new SemanticError('Semántico', $message, $line, $column);
    }

    private function getContextPosition($context): array
    {
        $line = 0;
        $column = 0;

        if ($context !== null && method_exists($context, 'getStart')) {
            $start = $context->getStart();
            if ($start !== null) {
                $line = $start->getLine();
                $column = $start->getCharPositionInLine();
            }
        }

        return [$line, $column];
    }

    private function makeArrayValue(string $elementType, int $size, array $values): array
    {
        if (count($values) > $size) {
            throw new Exception("El arreglo excede el tamaño declarado");
        }

        $normalized = [];
        foreach ($values as $value) {
            if (!$this->isCompatibleType($elementType, $value)) {
                throw new Exception("Tipo incompatible en arreglo. Se esperaba $elementType");
            }
            $normalized[] = $this->normalizeValueForType($elementType, $value);
        }

        while (count($normalized) < $size) {
            $normalized[] = $this->defaultValueForType($elementType);
        }

        return [
            'kind' => 'array',
            'elementType' => $elementType,
            'size' => $size,
            'values' => $normalized
        ];
    }

    private function defaultValueForType(string $type)
    {
        return match ($type) {
            'int32' => 0,
            'float32' => 0.0,
            'bool' => false,
            'string' => "",
            'rune' => "\0",
            default => null,
        };
    }

    private function inferType($value): string
    {
        if (is_array($value) && ($value['kind'] ?? null) === 'array') {
            return 'array';
        }

        if (is_int($value)) {
            return 'int32';
        }

        if (is_float($value)) {
            return 'float32';
        }

        if (is_string($value)) {
            return strlen($value) === 1 ? 'rune' : 'string';
        }

        if (is_bool($value)) {
            return 'bool';
        }

        if ($value === null) {
            return 'nil';
        }

        return 'unknown';
    }

    private function isCompatibleType(string $declaredType, $value): bool
    {
        if ($value === null) {
            return false;
        }

        return match ($declaredType) {
            'int32' => is_int($value),
            'float32' => is_float($value) || is_int($value),
            'bool' => is_bool($value),
            'string' => is_string($value),
            'rune' => is_string($value) && strlen($value) === 1,
            default => false,
        };
    }

    private function normalizeValueForType(string $declaredType, $value)
    {
        return match ($declaredType) {
            'float32' => (float)$value,
            'int32' => (int)$value,
            'rune' => is_string($value) ? substr($value, 0, 1) : $value,
            default => $value,
        };
    }

    private function formatValue($value): string
    {
        if (is_array($value) && ($value['kind'] ?? null) === 'array') {
            $items = array_map(fn($v) => $this->formatValue($v), $value['values']);
            return '[' . implode(', ', $items) . ']';
        }

        if (is_bool($value)) {
            return $value ? 'true' : 'false';
        }

        if ($value === null) {
            return 'nil';
        }

        return (string)$value;
    }

    private function executeForPart($ctx): void
    {
        if ($ctx === null) {
            return;
        }

        $this->visit($ctx);
    }

    private function assignArrayElement(string $id, $index, $newValue): void
    {
        $symbol = $this->symbolTable->get($id);

        if ($symbol->type !== 'array') {
            throw new Exception("'$id' no es un arreglo");
        }

        if (!is_int($index)) {
            throw new Exception("El índice del arreglo debe ser int32");
        }

        $arrayValue = $symbol->value;
        $values = $arrayValue['values'];
        $elementType = $arrayValue['elementType'];

        if ($index < 0 || $index >= count($values)) {
            throw new Exception("Índice fuera de rango en arreglo '$id'");
        }

        if (!$this->isCompatibleType($elementType, $newValue)) {
            throw new Exception("Tipo incompatible en posición de arreglo '$id'. Se esperaba $elementType");
        }

        $values[$index] = $this->normalizeValueForType($elementType, $newValue);
        $arrayValue['values'] = $values;

        $this->symbolTable->assign($id, $arrayValue, 'array');
    }

public function visitProgram($context)
{
    $mainCount = 0;

    foreach ($context->functionDecl() as $functionDecl) {
        $name = $functionDecl->ID()->getText();

        if (isset($this->functions[$name])) {
            $this->addError("La función '$name' ya fue declarada", $functionDecl);
            continue;
        }

        if ($name === 'main') {
            $mainCount++;
        }

        $this->functions[$name] = $functionDecl;
    }

    if ($mainCount === 0) {
        $this->addError("No se encontró la función main()", $context);
        return null;
    }

    if ($mainCount > 1) {
        $this->addError("Debe existir una y solo una función main()", $context);
        return null;
    }

    $mainDecl = $this->functions['main'];

    if ($mainDecl->paramList() !== null && count($mainDecl->paramList()->param()) > 0) {
        $this->addError("La función main() no puede recibir parámetros", $mainDecl);
        return null;
    }

    try {
        $this->callFunction('main', [], $context);
    } catch (Throwable $e) {
        $this->addError($e->getMessage(), $context);
    }

    return null;
}

private function callFunction(string $name, array $args, $context = null)
{
    if (!isset($this->functions[$name])) {
        throw new Exception("La función '$name' no existe");
    }

    $functionDecl = $this->functions[$name];
    $scopeName = 'func_' . $name . '_' . (++$this->callDepth);

    $previousFunction = $this->currentFunction;
    $this->currentFunction = $name;

    $this->symbolTable->enterScope($scopeName);

    try {
        $paramsNode = $functionDecl->paramList();
        $params = $paramsNode ? $paramsNode->param() : [];

        if (count($params) !== count($args)) {
            throw new Exception("La función '$name' esperaba " . count($params) . " parámetro(s)");
        }

        foreach ($params as $index => $paramCtx) {
            $paramName = $paramCtx->ID()->getText();
            $paramType = $paramCtx->typeSpec()->getText();
            [$line, $column] = $this->getContextPosition($paramCtx);

            $argValue = $args[$index];

            if (!$this->isCompatibleType($paramType, $argValue)) {
                throw new Exception("Tipo incompatible en parámetro '$paramName' de la función '$name'");
            }

            $argValue = $this->normalizeValueForType($paramType, $argValue);
            $this->symbolTable->define($paramName, $paramType, $argValue, $line, $column, false);
        }

        try {
            $this->visit($functionDecl->block());
        } catch (ReturnSignal $returnSignal) {
            return $returnSignal->value;
        }

        return null;
    } finally {
        $this->symbolTable->exitScope();
        $this->currentFunction = $previousFunction;
    }
}

    public function visitBlock($context)
    {
        $scopeName = 'block_' . (++$this->blockCounter);
        $this->symbolTable->enterScope($scopeName);

        try {
            foreach ($context->statement() as $statement) {
                $this->visit($statement);
            }
        } finally {
            $this->symbolTable->exitScope();
        }

        return null;
    }

    public function visitTypedVarDecl($context)
    {
        try {
            $id = $context->ID()->getText();
            $declaredType = $context->typeSpec()->getText();
            [$line, $column] = $this->getContextPosition($context);

            if ($context->expr() !== null) {
                $value = $this->visit($context->expr());

                if (!$this->isCompatibleType($declaredType, $value)) {
                    throw new Exception("Tipo incompatible en declaración de '$id'. Se esperaba $declaredType");
                }

                $value = $this->normalizeValueForType($declaredType, $value);
            } else {
                $value = $this->defaultValueForType($declaredType);
            }

            $this->symbolTable->define($id, $declaredType, $value, $line, $column, false);
        } catch (Throwable $e) {
            $this->addError($e->getMessage(), $context);
        }

        return null;
    }

    public function visitArrayVarDecl($context)
    {
        try {
            $id = $context->ID()->getText();
            $arrayValue = $this->visit($context->arrayLiteral());
            [$line, $column] = $this->getContextPosition($context);

            $this->symbolTable->define($id, 'array', $arrayValue, $line, $column, false);
        } catch (Throwable $e) {
            $this->addError($e->getMessage(), $context);
        }

        return null;
    }

    public function visitConstDecl($context)
    {
        try {
            $id = $context->ID()->getText();
            $value = $this->visit($context->expr());
            $type = $this->inferType($value);
            [$line, $column] = $this->getContextPosition($context);

            if ($type === 'unknown' || $type === 'nil' || $type === 'array') {
                throw new Exception("Expresión inválida en constante '$id'");
            }

            $this->symbolTable->define($id, $type, $value, $line, $column, true);
        } catch (Throwable $e) {
            $this->addError($e->getMessage(), $context);
        }

        return null;
    }

    public function visitShortVarDecl($context)
    {
        try {
            $id = $context->ID()->getText();
            $value = $this->visit($context->expr());
            $type = $this->inferType($value);
            [$line, $column] = $this->getContextPosition($context);

            if ($type === 'unknown' || $type === 'nil') {
                throw new Exception("Expresión inválida en declaración corta");
            }

            $this->symbolTable->define($id, $type, $value, $line, $column, false);
        } catch (Throwable $e) {
            $this->addError($e->getMessage(), $context);
        }

        return null;
    }

    public function visitVarDeclNoSemi($context)
    {
        return $this->visitTypedVarDecl($context);
    }

    public function visitShortVarDeclNoSemi($context)
    {
        return $this->visitShortVarDecl($context);
    }

    public function visitAssignStmt($context)
    {
        try {
            $id = $context->ID()->getText();

            if ($context->getChild(1)->getText() === '[') {
                $index = $this->visit($context->expr(0));
                $value = $this->visit($context->expr(1));
                $this->assignArrayElement($id, $index, $value);
                return null;
            }

            $symbol = $this->symbolTable->get($id);
            $value = $this->visit($context->expr(0));

            if ($symbol->type === 'array') {
                throw new Exception("No se puede asignar directamente a un arreglo");
            }

            if (!$this->isCompatibleType($symbol->type, $value)) {
                throw new Exception("Tipo incompatible en asignación para '$id'. Se esperaba {$symbol->type}");
            }

            $value = $this->normalizeValueForType($symbol->type, $value);
            $this->symbolTable->assign($id, $value, $symbol->type);
        } catch (Throwable $e) {
            $this->addError($e->getMessage(), $context);
        }

        return null;
    }

    public function visitAssignNoSemi($context)
    {
        return $this->visitAssignStmt($context);
    }

    public function visitCompoundAssignStmt($context)
    {
        try {
            $id = $context->ID()->getText();
            $symbol = $this->symbolTable->get($id);
            $right = $this->visit($context->expr());
            $op = $context->op->getText();
            $left = $symbol->value;

            if ($symbol->type === 'array') {
                throw new Exception("No se permite asignación compuesta sobre arreglos");
            }

            $result = null;

            switch ($op) {
                case '+=':
                    if (is_string($left) || is_string($right)) {
                        $result = (string)$left . (string)$right;
                    } else {
                        $result = $left + $right;
                    }
                    break;
                case '-=':
                    $result = $left - $right;
                    break;
                case '*=':
                    $result = $left * $right;
                    break;
                case '/=':
                    if ($right == 0) {
                        throw new Exception("División entre cero");
                    }
                    $result = $left / $right;
                    break;
            }

            if (!$this->isCompatibleType($symbol->type, $result)) {
                throw new Exception("Tipo incompatible en asignación compuesta para '$id'");
            }

            $result = $this->normalizeValueForType($symbol->type, $result);
            $this->symbolTable->assign($id, $result, $symbol->type);
        } catch (Throwable $e) {
            $this->addError($e->getMessage(), $context);
        }

        return null;
    }

    public function visitCompoundAssignNoSemi($context)
    {
        return $this->visitCompoundAssignStmt($context);
    }

public function visitPrintStmt($context)
{
    try {
        $parts = [];

        if ($context->exprList() !== null) {
            foreach ($context->exprList()->expr() as $exprCtx) {
                $value = $this->visit($exprCtx);
                $parts[] = $this->formatValue($value);
            }
        }

        $this->output .= implode(' ', $parts) . PHP_EOL;
    } catch (Throwable $e) {
        $this->addError($e->getMessage(), $context);
    }

    return null;
}

    public function visitIfStmt($context)
    {
        try {
            $condition = $this->visit($context->expr());

            if (!is_bool($condition)) {
                throw new Exception("La condición del if debe ser booleana");
            }

            if ($condition) {
                $this->visit($context->block(0));
            } elseif ($context->block(1) !== null) {
                $this->visit($context->block(1));
            }
        } catch (Throwable $e) {
            $this->addError($e->getMessage(), $context);
        }

        return null;
    }

    public function visitSwitchStmt($context)
    {
        try {
            $switchValue = $this->visit($context->expr());
            $matched = false;

            foreach ($context->switchCase() as $caseCtx) {
                $caseValue = $this->visit($caseCtx->expr());

                if ($switchValue == $caseValue) {
                    $matched = true;

                    foreach ($caseCtx->statement() as $stmt) {
                        $this->visit($stmt);
                    }

                    break;
                }
            }

            if (!$matched && $context->defaultCase() !== null) {
                foreach ($context->defaultCase()->statement() as $stmt) {
                    $this->visit($stmt);
                }
            }
        } catch (Throwable $e) {
            $this->addError($e->getMessage(), $context);
        }

        return null;
    }

    public function visitForCondStmt($context)
    {
        $this->loopDepth++;

        try {
            while (true) {
                $condition = $this->visit($context->expr());

                if (!is_bool($condition)) {
                    throw new Exception("La condición del for debe ser booleana");
                }

                if (!$condition) {
                    break;
                }

                try {
                    $this->visit($context->block());
                } catch (ContinueSignal $e) {
                    continue;
                } catch (BreakSignal $e) {
                    break;
                }
            }
        } catch (Throwable $e) {
            $this->addError($e->getMessage(), $context);
        } finally {
            $this->loopDepth--;
        }

        return null;
    }

    public function visitForClassicStmt($context)
    {
        $this->loopDepth++;

        try {
            if ($context->forInit() !== null) {
                $this->executeForPart($context->forInit());
            }

            while (true) {
                if ($context->forCondition() !== null) {
                    $condition = $this->visit($context->forCondition()->expr());

                    if (!is_bool($condition)) {
                        throw new Exception("La condición del for debe ser booleana");
                    }

                    if (!$condition) {
                        break;
                    }
                }

                try {
                    $this->visit($context->block());
                } catch (ContinueSignal $e) {
                    if ($context->forUpdate() !== null) {
                        $this->executeForPart($context->forUpdate());
                    }
                    continue;
                } catch (BreakSignal $e) {
                    break;
                }

                if ($context->forUpdate() !== null) {
                    $this->executeForPart($context->forUpdate());
                }
            }
        } catch (Throwable $e) {
            $this->addError($e->getMessage(), $context);
        } finally {
            $this->loopDepth--;
        }

        return null;
    }

    public function visitBreakStmt($context)
    {
        if ($this->loopDepth <= 0) {
            throw new Exception("break solo puede usarse dentro de un for");
        }

        throw new BreakSignal();
    }

    public function visitContinueStmt($context)
    {
        if ($this->loopDepth <= 0) {
            throw new Exception("continue solo puede usarse dentro de un for");
        }

        throw new ContinueSignal();
    }

public function visitReturnStmt($context)
{
    if ($this->currentFunction === 'main' && $context->expr() !== null) {
        throw new Exception("La función main() no puede retornar valores");
    }

    $value = null;

    if ($context->expr() !== null) {
        $value = $this->visit($context->expr());
    }

    throw new ReturnSignal($value);
}

    public function visitExprStmt($context)
    {
        try {
            $this->visit($context->expr());
        } catch (Throwable $e) {
            $this->addError($e->getMessage(), $context);
        }

        return null;
    }

    public function visitBuiltinExpr($context)
    {
        return $this->visit($context->builtinCall());
    }

public function visitBuiltinCall($context)
{
    $name = $context->getChild(0)->getText();

    if ($name === 'now') {
        return date('Y-m-d H:i:s');
    }

    if ($name === 'len') {
        $value = $this->visit($context->expr(0));

        if (is_string($value)) {
            return strlen($value);
        }

        if (is_array($value) && ($value['kind'] ?? null) === 'array') {
            return count($value['values']);
        }

        throw new Exception("len solo acepta string o arreglo");
    }

    if ($name === 'typeOf') {
        $value = $this->visit($context->expr(0));

        if (is_array($value) && ($value['kind'] ?? null) === 'array') {
            return 'array';
        }

        return $this->inferType($value);
    }

    if ($name === 'substr') {
        $source = $this->visit($context->expr(0));
        $start = $this->visit($context->expr(1));
        $length = $this->visit($context->expr(2));

        if (!is_string($source)) {
            throw new Exception("substr requiere que el primer parámetro sea string");
        }

        if (!is_int($start) || !is_int($length)) {
            throw new Exception("substr requiere índices int32");
        }

        if ($start < 0 || $length < 0) {
            throw new Exception("substr no acepta índices negativos");
        }

        if ($start > strlen($source)) {
            throw new Exception("Índice inicial fuera de rango en substr");
        }

        if (($start + $length) > strlen($source)) {
            throw new Exception("La longitud solicitada excede el tamaño del string en substr");
        }

        return substr($source, $start, $length);
    }

    throw new Exception("Builtin no reconocido");
}

public function visitCallExpr($context)
{
    $functionName = $context->ID()->getText();

    if ($functionName === 'main') {
        throw new Exception("La función main() no puede ser llamada explícitamente");
    }

    $args = [];

    if ($context->argList() !== null) {
        foreach ($context->argList()->expr() as $exprCtx) {
            $args[] = $this->visit($exprCtx);
        }
    }

    return $this->callFunction($functionName, $args, $context);
}

    public function visitArrayLiteralExpr($context)
    {
        return $this->visit($context->arrayLiteral());
    }

    public function visitArrayLiteral($context)
    {
        $size = (int)$context->arrayType()->INT()->getText();
        $elementType = $context->arrayType()->typeSpec()->getText();
        $values = [];

        if ($context->exprList() !== null) {
            foreach ($context->exprList()->expr() as $exprCtx) {
                $values[] = $this->visit($exprCtx);
            }
        }

        return $this->makeArrayValue($elementType, $size, $values);
    }

    public function visitArrayAccessExpr($context)
    {
        $id = $context->ID()->getText();
        $arraySymbol = $this->symbolTable->get($id);

        if ($arraySymbol->type !== 'array') {
            throw new Exception("'$id' no es un arreglo");
        }

        $index = $this->visit($context->expr());

        if (!is_int($index)) {
            throw new Exception("El índice del arreglo debe ser int32");
        }

        $arrayValue = $arraySymbol->value;
        $values = $arrayValue['values'];

        if ($index < 0 || $index >= count($values)) {
            throw new Exception("Índice fuera de rango en arreglo '$id'");
        }

        return $values[$index];
    }

    public function visitIntExpr($context)
    {
        return (int)$context->INT()->getText();
    }

    public function visitFloatExpr($context)
    {
        return (float)$context->FLOAT()->getText();
    }

    public function visitBoolExpr($context)
    {
        return $context->BOOL()->getText() === 'true';
    }

    public function visitStringExpr($context)
    {
        $text = $context->STRING()->getText();
        $text = substr($text, 1, -1);
        return stripcslashes($text);
    }

    public function visitRuneExpr($context)
    {
        $text = $context->RUNE()->getText();
        $text = substr($text, 1, -1);
        return stripcslashes($text);
    }

    public function visitNilExpr($context)
    {
        return null;
    }

    public function visitIdExpr($context)
    {
        $id = $context->ID()->getText();
        return $this->symbolTable->get($id)->value;
    }

    public function visitParenExpr($context)
    {
        return $this->visit($context->expr());
    }

    public function visitNotExpr($context)
    {
        $value = $this->visit($context->expr());

        if (!is_bool($value)) {
            throw new Exception("El operador ! solo acepta booleanos");
        }

        return !$value;
    }

    public function visitAddSubExpr($context)
    {
        $left = $this->visit($context->expr(0));
        $right = $this->visit($context->expr(1));
        $op = $context->op->getText();

        if ((is_string($left) || is_string($right)) && $op !== '+') {
            throw new Exception("Solo se permite concatenar strings con +");
        }

        if ($left === null || $right === null) {
            throw new Exception("No se puede operar con nil");
        }

        if (is_array($left) || is_array($right)) {
            throw new Exception("No se puede operar aritméticamente con arreglos");
        }

        if ($op === '+') {
            if (is_string($left) || is_string($right)) {
                return (string)$left . (string)$right;
            }
            return $left + $right;
        }

        return $left - $right;
    }

    public function visitMulDivExpr($context)
    {
        $left = $this->visit($context->expr(0));
        $right = $this->visit($context->expr(1));
        $op = $context->op->getText();

        if ($left === null || $right === null) {
            throw new Exception("No se puede operar con nil");
        }

        if (is_array($left) || is_array($right)) {
            throw new Exception("No se puede operar aritméticamente con arreglos");
        }

        if (!is_int($left) && !is_float($left)) {
            throw new Exception("Operación aritmética inválida");
        }

        if (!is_int($right) && !is_float($right)) {
            throw new Exception("Operación aritmética inválida");
        }

        if ($op === '*') {
            return $left * $right;
        }

        if ($right == 0) {
            throw new Exception("División entre cero");
        }

        return $left / $right;
    }

    public function visitRelExpr($context)
    {
        $left = $this->visit($context->expr(0));
        $right = $this->visit($context->expr(1));
        $op = $context->op->getText();

        if ($left === null || $right === null) {
            throw new Exception("No se puede comparar con nil");
        }

        if (is_array($left) || is_array($right)) {
            throw new Exception("No se puede comparar arreglos");
        }

        return match ($op) {
            '>' => $left > $right,
            '<' => $left < $right,
            '>=' => $left >= $right,
            '<=' => $left <= $right,
            '==' => $left == $right,
            '!=' => $left != $right,
        };
    }

    public function visitLogicExpr($context)
    {
        $op = $context->op->getText();
        $left = $this->visit($context->expr(0));

        if (!is_bool($left)) {
            throw new Exception("Los operadores lógicos solo aceptan booleanos");
        }

        if ($op === '&&') {
            if ($left === false) {
                return false;
            }

            $right = $this->visit($context->expr(1));

            if (!is_bool($right)) {
                throw new Exception("Los operadores lógicos solo aceptan booleanos");
            }

            return $left && $right;
        }

        if ($op === '||') {
            if ($left === true) {
                return true;
            }

            $right = $this->visit($context->expr(1));

            if (!is_bool($right)) {
                throw new Exception("Los operadores lógicos solo aceptan booleanos");
            }

            return $left || $right;
        }

        throw new Exception("Operador lógico no válido");
    }
}