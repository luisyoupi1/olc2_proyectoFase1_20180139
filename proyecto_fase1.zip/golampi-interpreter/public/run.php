<?php

header('Content-Type: application/json');

use Antlr\Antlr4\Runtime\InputStream;
use Antlr\Antlr4\Runtime\CommonTokenStream;

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../generated/grammar/GolampiLexer.php';
require_once __DIR__ . '/../generated/grammar/GolampiParser.php';
require_once __DIR__ . '/../src/Interpreter/GolampiInterpreter.php';
require_once __DIR__ . '/../src/Interpreter/SyntaxErrorListener.php';

try {
    $data = json_decode(file_get_contents('php://input'), true);
    $code = $data['code'] ?? '';

    if (trim($code) === '') {
        echo json_encode([
            'output' => 'No se recibió código.',
            'symbols' => [],
            'errors' => []
        ]);
        exit;
    }

    $input = InputStream::fromString($code);

    $lexer = new GolampiLexer($input);
    $lexerErrorListener = new SyntaxErrorListener();
    $lexer->removeErrorListeners();
    $lexer->addErrorListener($lexerErrorListener);

    $tokens = new CommonTokenStream($lexer);

    $parser = new GolampiParser($tokens);
    $parserErrorListener = new SyntaxErrorListener();
    $parser->removeErrorListeners();
    $parser->addErrorListener($parserErrorListener);

    $tree = $parser->program();

    $errors = [];

    foreach ($lexerErrorListener->getErrors() as $error) {
        $errors[] = $error;
    }

    foreach ($parserErrorListener->getErrors() as $error) {
        $errors[] = $error;
    }

    if (count($errors) > 0) {
        echo json_encode([
            'output' => '',
            'symbols' => [],
            'errors' => $errors
        ]);
        exit;
    }

    $interpreter = new GolampiInterpreter();
    $interpreter->visit($tree);

    $symbols = [];
    foreach ($interpreter->getSymbolTable() as $symbol) {
        $symbols[] = [
            'id' => $symbol->id,
            'type' => $symbol->type,
            'value' => is_bool($symbol->value) ? ($symbol->value ? 'true' : 'false') : $symbol->value,
            'scope' => $symbol->scope,
            'line' => $symbol->line,
            'column' => $symbol->column,
            'isConst' => $symbol->isConst
        ];
    }

    foreach ($interpreter->getErrors() as $error) {
        $errors[] = [
            'type' => $error->type,
            'message' => $error->message,
            'line' => $error->line,
            'column' => $error->column
        ];
    }

    echo json_encode([
        'output' => $interpreter->getOutput(),
        'symbols' => $symbols,
        'errors' => $errors
    ]);
} catch (Throwable $e) {
    echo json_encode([
        'output' => 'Error interno: ' . $e->getMessage(),
        'symbols' => [],
        'errors' => []
    ]);
}