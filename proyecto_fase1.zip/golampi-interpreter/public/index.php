<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Intérprete Golampi</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Intérprete Golampi</h1>

        <textarea id="code" placeholder='Escribe tu código aquí...'>func main() {
    fmt.Println("Hola mundo");
}</textarea>

        <div class="buttons">
            <button onclick="ejecutarCodigo()">Ejecutar / Analizar</button>
            <button onclick="limpiarEditor()">Limpiar editor</button>
            <button onclick="limpiarSalida()">Limpiar consola</button>
        </div>

        <h2>Salida</h2>
        <pre id="output"></pre>

        <h2>Tabla de símbolos</h2>
        <pre id="symbols"></pre>

        <h2>Tabla de errores</h2>
        <pre id="errors"></pre>
    </div>

    <script src="app.js"></script>
</body>
</html>