async function ejecutarCodigo() {
    const code = document.getElementById('code').value;
    const output = document.getElementById('output');
    const symbols = document.getElementById('symbols');
    const errors = document.getElementById('errors');

    output.textContent = 'Procesando...';
    symbols.textContent = '';
    errors.textContent = '';

    try {
        const response = await fetch('run.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ code })
        });

        const data = await response.json();

        output.textContent = data.output || '';

        if (data.symbols && data.symbols.length > 0) {
            symbols.textContent = data.symbols
                .map(s => `ID: ${s.id} | Tipo: ${s.type} | Valor: ${s.value} | Ámbito: ${s.scope} | Línea: ${s.line} | Columna: ${s.column} | Constante: ${s.isConst ? 'sí' : 'no'}`)
                .join('\n');
        } else {
            symbols.textContent = 'Sin símbolos.';
        }

        if (data.errors && data.errors.length > 0) {
            errors.textContent = data.errors
                .map((e, i) => `${i + 1}. ${e.type} | Línea: ${e.line} | Columna: ${e.column} | ${e.message}`)
                .join('\n');
        } else {
            errors.textContent = 'Sin errores.';
        }

    } catch (error) {
        output.textContent = 'Error al conectar con el servidor: ' + error.message;
        symbols.textContent = '';
        errors.textContent = '';
    }
}

function limpiarEditor() {
    document.getElementById('code').value = '';
}

function limpiarSalida() {
    document.getElementById('output').textContent = '';
    document.getElementById('symbols').textContent = '';
    document.getElementById('errors').textContent = '';
}