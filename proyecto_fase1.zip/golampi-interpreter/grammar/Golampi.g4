grammar Golampi;

program
    : functionDecl* EOF
    ;

functionDecl
    : 'func' ID '(' paramList? ')' block
    ;

paramList
    : param (',' param)*
    ;

param
    : ID typeSpec
    ;

statement
    : varDecl
    | constDecl
    | shortVarDecl
    | assignStmt
    | compoundAssignStmt
    | printStmt
    | ifStmt
    | switchStmt
    | forStmt
    | breakStmt
    | continueStmt
    | returnStmt
    | exprStmt
    ;

block
    : '{' statement* '}'
    ;

varDecl
    : 'var' ID typeSpec ('=' expr)? ';'?                      # TypedVarDecl
    | 'var' ID '=' arrayLiteral ';'?                          # ArrayVarDecl
    ;

constDecl
    : 'const' ID '=' expr ';'?
    ;

shortVarDecl
    : ID ':=' expr ';'?
    ;

assignStmt
    : ID '=' expr ';'?
    | ID '[' expr ']' '=' expr ';'?
    ;

compoundAssignStmt
    : ID op=('+='|'-='|'*='|'/=') expr ';'?
    ;

printStmt
    : 'fmt.Println' '(' exprList? ')' ';'?
    ;

ifStmt
    : 'if' expr block ('else' block)?
    ;

switchStmt
    : 'switch' expr '{' switchCase* defaultCase? '}'
    ;

switchCase
    : 'case' expr ':' statement*
    ;

defaultCase
    : 'default' ':' statement*
    ;

forStmt
    : 'for' expr block                                                      # ForCondStmt
    | 'for' forInit? ';' forCondition? ';' forUpdate? block                 # ForClassicStmt
    ;

forInit
    : varDeclNoSemi
    | shortVarDeclNoSemi
    | assignNoSemi
    | compoundAssignNoSemi
    ;

forCondition
    : expr
    ;

forUpdate
    : assignNoSemi
    | compoundAssignNoSemi
    | expr
    ;

varDeclNoSemi
    : 'var' ID typeSpec ('=' expr)?
    ;

shortVarDeclNoSemi
    : ID ':=' expr
    ;

assignNoSemi
    : ID '=' expr
    | ID '[' expr ']' '=' expr
    ;

compoundAssignNoSemi
    : ID op=('+='|'-='|'*='|'/=') expr
    ;

breakStmt
    : 'break' ';'?
    ;

continueStmt
    : 'continue' ';'?
    ;

returnStmt
    : 'return' expr? ';'?
    ;

exprStmt
    : expr ';'?
    ;

typeSpec
    : 'int32'
    | 'float32'
    | 'bool'
    | 'string'
    | 'rune'
    ;

arrayType
    : '[' INT ']' typeSpec
    ;

arrayLiteral
    : arrayType '{' exprList? '}'
    ;

exprList
    : expr (',' expr)*
    ;

expr
    : '!' expr                                         # NotExpr
    | expr op=('*'|'/') expr                           # MulDivExpr
    | expr op=('+'|'-') expr                           # AddSubExpr
    | expr op=('>'|'<'|'>='|'<='|'=='|'!=') expr       # RelExpr
    | expr op=('&&'|'||') expr                         # LogicExpr
    | builtinCall                                      # BuiltinExpr
    | ID '(' argList? ')'                              # CallExpr
    | ID '[' expr ']'                                  # ArrayAccessExpr
    | arrayLiteral                                     # ArrayLiteralExpr
    | FLOAT                                            # FloatExpr
    | INT                                              # IntExpr
    | BOOL                                             # BoolExpr
    | STRING                                           # StringExpr
    | RUNE                                             # RuneExpr
    | 'nil'                                            # NilExpr
    | ID                                               # IdExpr
    | '(' expr ')'                                     # ParenExpr
    ;

builtinCall
    : 'len' '(' expr ')'
    | 'typeOf' '(' expr ')'
    | 'now' '(' ')'
    | 'substr' '(' expr ',' expr ',' expr ')'
    ;
    
argList
    : expr (',' expr)*
    ;

BOOL
    : 'true'
    | 'false'
    ;

RUNE
    : '\'' (~['\\] | '\\' .) '\''
    ;

ID
    : [a-zA-Z_][a-zA-Z0-9_]*
    ;

FLOAT
    : [0-9]+ '.' [0-9]+
    ;

INT
    : [0-9]+
    ;

STRING
    : '"' (~["\\] | '\\' .)* '"'
    ;

WS
    : [ \t\r\n]+ -> skip
    ;